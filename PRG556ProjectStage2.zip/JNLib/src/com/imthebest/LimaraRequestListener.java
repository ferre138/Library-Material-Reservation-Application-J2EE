//Nam Nguyen
package com.imthebest;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

/**
 * Application Lifecycle Listener implementation class LimaraRequestListener
 *
 */
public class LimaraRequestListener implements ServletRequestListener {

    /**
     * Default constructor. 
     */
    public LimaraRequestListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletRequestListener#requestDestroyed(ServletRequestEvent)
     */
    public void requestDestroyed(ServletRequestEvent sre) {
        // TODO Auto-generated method stub
    }

	/**
     * @see ServletRequestListener#requestInitialized(ServletRequestEvent)
     */
    public void requestInitialized(ServletRequestEvent sre) {
        // TODO Auto-generated method stub
    }
	
}
